#!/bin/bash
# 사용법: CF_ID=<CloudFront 배포 ID> bash apply-kms-policy.sh
#  - CF_ID를 비우면 data 키는 건너뜀 (CloudFront 만든 뒤 다시 실행)
set -e
ACC=$(aws sts get-caller-identity --query Account --output text)
cd "$(dirname "$0")"

# EBS 암호화용 Auto Scaling 서비스 연결 역할 (이미 있으면 에러 무시)
aws iam create-service-linked-role --aws-service-name autoscaling.amazonaws.com >/dev/null 2>&1 || true

put() { # $1=alias 이름, $2=정책 파일, $3=리전
  local id; id=$(aws kms describe-key --region "$3" --key-id "alias/$1" --query KeyMetadata.KeyId --output text)
  sed -e "s/<ACCOUNT_ID>/$ACC/g" -e "s/<CF_DISTRIBUTION_ID>/${CF_ID}/g" "$2" > "/tmp/$1-$3.json"
  aws kms put-key-policy --region "$3" --key-id "$id" --policy-name default --policy "file:///tmp/$1-$3.json"
  echo "applied: $1 ($3) $id"
}

put unicorn-kms-app      unicorn-kms-app-policy.json      ap-northeast-2
put unicorn-kms-platform unicorn-kms-platform-policy.json ap-northeast-2
# 다중 리전 복제본(us-east-1)은 정책이 따로라 한 번 더 적용
put unicorn-kms-platform unicorn-kms-platform-policy.json us-east-1 || echo "us-east-1 복제본/alias 확인 필요"
if [ -n "$CF_ID" ]; then
  put unicorn-kms-data unicorn-kms-data-policy.json ap-northeast-2
else
  echo "skip: unicorn-kms-data (CF_ID 미지정)"
fi
