#!/bin/bash

echo "Task 1 Marking"
# export AWS_ACCESS_KEY_ID=""
# export AWS_SECRET_ACCESS_KEY=""
# rm -rf ~/.aws
# aws sts get-caller-identity | jq .Account

read -r -p "채점 전 kubectl-connect 또는 update-kubeconfig를 실행하고 선수 등번호를 number 환경변수로 설정했습니까? [y/N] " SETUP_READY
case "${SETUP_READY:-N}" in
  y|Y|yes|YES)
    ;;
  *)
    echo "kubectl 연결과 'export number=<선수등번호>' 설정 후 채점 스크립트를 다시 실행하세요."
    exit 1
    ;;
esac

if [ -z "${number:-}" ]; then
  echo "선수 등번호가 설정되지 않았습니다. 'export number=<선수등번호>' 실행 후 다시 시도하세요."
  exit 1
fi

echo "채점준비 끝! 채점 시작!"

echo "=== 1-1-A ==="
aws ec2 describe-vpcs --filters Name=tag:Name,Values=unicorn-vpc --query "Vpcs[].CidrBlock" --output json | jq -r ".[]"
aws ec2 describe-subnets --filters Name=tag:Name,Values=unicorn-subnet-pub-a,unicorn-subnet-pub-b,unicorn-subnet-pub-c,unicorn-subnet-priv-a,unicorn-subnet-priv-b,unicorn-subnet-priv-c --query "Subnets[].CidrBlock" --output text

echo "=== 1-2-A ==="
aws ec2 describe-route-tables --filters "Name=tag:Name,Values=unicorn-rt-*" --query "RouteTables[].[Tags[?Key=='Name']|[0].Value, Routes[?DestinationCidrBlock=='0.0.0.0/0']|[0].GatewayId, Routes[?DestinationCidrBlock=='0.0.0.0/0']|[0].NatGatewayId, length(Associations[?SubnetId!=null])]" --output text

echo "=== 1-3-A ==="
VPC_ID=$(aws ec2 describe-vpcs --filters Name=tag:Name,Values=unicorn-vpc --query "Vpcs[0].VpcId" --output text)
aws ec2 describe-vpc-endpoints --filters Name=vpc-id,Values=$VPC_ID --query "VpcEndpoints[].ServiceName" --output json | jq -r ".[]"
aws ec2 describe-flow-logs --filter Name=resource-id,Values=$VPC_ID --query "length(FlowLogs)" --output text

echo "=== 2-1-A ==="
for a in app data platform; do
  aws kms get-key-rotation-status --key-id $(aws kms describe-key --key-id alias/unicorn-kms-$a --query "KeyMetadata.KeyId" --output text) --query "[KeyRotationEnabled, RotationPeriodInDays]" --output text
done

echo "=== 3-1-A ==="
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
BUCKET=unicorn-web-$ACCOUNT_ID
aws s3api list-buckets --query "Buckets[?contains(Name, 'unicorn-web-')].Name" | jq -r '.[]'
aws s3api get-public-access-block --bucket $BUCKET --query "PublicAccessBlockConfiguration" --output json | jq -r 'to_entries | map(.value) | @tsv'
aws s3api get-bucket-versioning --bucket $BUCKET --query "Status" --output text
aws s3api get-bucket-encryption --bucket $BUCKET --query "ServerSideEncryptionConfiguration.Rules[0].ApplyServerSideEncryptionByDefault.[SSEAlgorithm, KMSMasterKeyID]" --output text

echo "=== 4-1-A ==="
aws dynamodb describe-table --table-name unicorn-concert-db --query "Table.{Billing:BillingModeSummary.BillingMode, PK:KeySchema[?KeyType=='HASH'].AttributeName|[0], GSIName:GlobalSecondaryIndexes[0].IndexName, GSI_PK:GlobalSecondaryIndexes[0].KeySchema[?KeyType=='HASH'].AttributeName|[0], GSI_SK:GlobalSecondaryIndexes[0].KeySchema[?KeyType=='RANGE'].AttributeName|[0], GSIProj:GlobalSecondaryIndexes[0].Projection.ProjectionType, SSEType:SSEDescription.SSEType, SSEKms:SSEDescription.KMSMasterKeyArn, Delete:DeletionProtectionEnabled}" --output json
aws dynamodb describe-continuous-backups --table-name unicorn-concert-db --query "ContinuousBackupsDescription.PointInTimeRecoveryDescription.PointInTimeRecoveryStatus" --output text

echo "=== 5-1-A ==="
aws ecr describe-repositories --repository-names unicorn-concert-app --query "repositories[0].{Scan:imageScanningConfiguration.scanOnPush, Mutability:imageTagMutability, Enc:encryptionConfiguration.encryptionType}" --output json | jq -r ".[]"
aws ecr describe-images --repository-name unicorn-concert-app --query "sort(imageDetails[].imageTags[])" --output json | jq -r '@tsv'
aws ecr describe-image-scan-findings --repository-name unicorn-concert-app --image-id imageTag=v1.0.0 --query "imageScanFindings.findingSeverityCounts" --output json | jq .

echo "=== 6-1-A ==="
aws eks describe-cluster --name unicorn-eks-cluster --query "cluster.version" --output text
aws eks describe-cluster --name unicorn-eks-cluster --query "cluster.resourcesVpcConfig.[endpointPublicAccess, endpointPrivateAccess]" --output json | jq -r '@tsv'
aws eks describe-cluster --name unicorn-eks-cluster --query "cluster.logging.clusterLogging[?enabled==\`true\`].types[]" --output json | jq -r '@tsv'
aws eks describe-cluster --name unicorn-eks-cluster --query "cluster.encryptionConfig[].provider.keyArn" --output text
aws eks describe-cluster --name unicorn-eks-cluster --query "cluster.accessConfig.authenticationMode" --output text

echo "=== 6-2-A ==="
kubectl get nodes -l unicorn=app -o jsonpath='{range .items[*]}{.metadata.labels.topology\.kubernetes\.io/zone}{"\n"}{end}'
kubectl get nodes -l unicorn=addon --no-headers | wc -l
aws ec2 describe-instances --filters Name=tag:Name,Values=unicorn-k8snode-app-node Name=instance-state-name,Values=running --query "length(Reservations[].Instances[])" --output text
aws ec2 describe-instances --filters Name=tag:Name,Values=unicorn-k8snode-addon-node Name=instance-state-name,Values=running --query "length(Reservations[].Instances[])" --output text
aws ec2 describe-instances --filters Name=tag:Name,Values=unicorn-k8snode-app-node Name=instance-state-name,Values=running --query "Reservations[].Instances[].PublicIpAddress" --output json

echo "=== 6-3-A ==="
kubectl get deploy unicorn-book-app-deploy -n unicorn -o custom-columns='NAME:.metadata.name,READY:.status.readyReplicas,AVAILABLE:.status.availableReplicas' --no-headers
kubectl get svc unicorn-book-app-svc -n unicorn -o custom-columns='NAME:.metadata.name,TYPE:.spec.type' --no-headers
kubectl get deploy unicorn-book-app-deploy -n unicorn -o jsonpath='liveness={.spec.template.spec.containers[0].livenessProbe.httpGet.path} readiness={.spec.template.spec.containers[0].readinessProbe.httpGet.path}{"\n"}graceful={.spec.template.spec.terminationGracePeriodSeconds} preStop={.spec.template.spec.containers[0].lifecycle.preStop}{"\n"}'
kubectl get pods -n unicorn -l app -o jsonpath='{range .items[*]}{.spec.nodeSelector.unicorn}{"\n"}{end}' | sort -u
aws eks list-pod-identity-associations --cluster-name unicorn-eks-cluster --namespace unicorn --query "associations[].serviceAccount" --output text

echo "=== 7-1-A ==="
aws lambda get-function-configuration --function-name unicorn-get-booking-func --query "[FunctionName, KMSKeyArn, LoggingConfig.LogGroup]" --output json | jq -r ".[]"

echo "=== 8-1-A ==="
ALB_ARN=$(aws elbv2 describe-load-balancers --names unicorn-alb --query "LoadBalancers[0].LoadBalancerArn" --output text)
aws elbv2 describe-load-balancers --load-balancer-arns $ALB_ARN --query "LoadBalancers[0].[Scheme, Type, State.Code]" --output text
aws elbv2 describe-listeners --load-balancer-arn $ALB_ARN --query "Listeners[0].[Protocol, Port]" --output text
aws elbv2 describe-target-groups --names unicorn-tg --query "TargetGroups[0].TargetGroupName" --output text

echo "=== 8-2-A ==="
aws cloudfront get-distribution-config --id $(aws cloudfront list-distributions --query "DistributionList.Items[?Comment=='unicorn-svc-cf'].Id | [0]" --output text) --query "DistributionConfig.Origins.Items[].[Id, OriginAccessControlId, VpcOriginConfig.VpcOriginId]" --output text
aws s3api get-bucket-policy --bucket unicorn-web-$(aws sts get-caller-identity --query Account --output text) --query "Policy" --output text | jq -r '.Statement[] | .Principal.Service, .Condition.StringEquals."AWS:SourceArn"'

echo "=== 8-3-A ==="
CF=$(aws cloudfront list-distributions --query "DistributionList.Items[?Comment=='unicorn-svc-cf'].DomainName | [0]" --output text)
RESP=$(curl -s -X POST "https://$CF/v1/book" -H 'Content-Type: application/json' -d '{"client_id":"C-MARK","username":"Judge","email":"judge@skills.kr","concert_name":"UnicornMark2026"}')
echo "$RESP"
BID=$(echo "$RESP" | jq -r '.booking_id')
aws dynamodb get-item --table-name unicorn-concert-db --key "{\"booking_id\":{\"S\":\"$BID\"}}" --query "Item.{booking_id:booking_id.S, client_id:client_id.S, concert_name:concert_name.S, created_at:created_at.S}" --output json

echo "=== 8-4-A ==="
curl -s "https://$CF/v1/book?booking_id=$BID" | jq .

echo "=== 8-5-A ==="
curl -s -o /dev/null -w "%{http_code}\n" --max-time 10 -X POST "http://$(aws elbv2 describe-load-balancers --names unicorn-alb --query "LoadBalancers[0].DNSName" --output text)/v1/book" -H 'Content-Type: application/json' -d '{"client_id":"DIRECT"}' || echo "000"

echo "=== 8-6-A ==="
curl -s -o /dev/null -w "%{http_code}\n" "https://$CF/?probe=<script>alert(1)</script>"

echo "=== 9-1-A ==="
aws iam get-role --role-name unicorn-audit-role --output json | jq -r '.Role | [.MaxSessionDuration, .AssumeRolePolicyDocument.Statement[0].Principal.AWS, .AssumeRolePolicyDocument.Statement[0].Condition.StringEquals["sts:ExternalId"]] | map(tostring) | join(" ")'
for p in $(aws iam list-role-policies --role-name unicorn-audit-role --query "PolicyNames[]" --output text); do
  aws iam get-role-policy --role-name unicorn-audit-role --policy-name $p --query "PolicyDocument.Statement[].Action[]" --output text; done

echo "=== 9-2-A ==="
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ROLE_ARN=arn:aws:iam::$ACCOUNT_ID:role/unicorn-audit-role
echo "[1] no external-id:"; aws sts assume-role --role-arn $ROLE_ARN --role-session-name mk 2>&1 | grep -oE AccessDenied | head -1
read -r AK SK TK < <(aws sts assume-role --role-arn $ROLE_ARN --role-session-name mk --external-id unicorn-audit-2026$number --query "Credentials.[AccessKeyId,SecretAccessKey,SessionToken]" --output text)
export AWS_ACCESS_KEY_ID=$AK AWS_SECRET_ACCESS_KEY=$SK AWS_SESSION_TOKEN=$TK
echo "[2] assumed:"; aws sts get-caller-identity --query Arn --output text
echo "[3] allowed:"; aws ec2 describe-vpcs --filters Name=tag:Name,Values=unicorn-vpc --query "Vpcs[0].VpcId" --output text
echo "[4] denied:"; aws ec2 describe-instances 2>&1 | grep -oE "AccessDenied|UnauthorizedOperation" | head -1
unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN

echo "=== 10-1-A ==="
curl -s -o /dev/null -w "%{http_code}\n" "https://$(aws cloudfront list-distributions --query "DistributionList.Items[?Comment=='unicorn-svc-cf'].DomainName | [0]" --output text)/health"
kubectl exec -n unicorn $(kubectl get pods -n unicorn -l app -o jsonpath='{.items[0].metadata.name}') -c book -- printenv AWS_REGION TABLE_NAME

echo "=== 11-1-A ==="
aws logs get-log-events --log-group-name /unicorn/eks/book-app --log-stream-name "$(aws logs describe-log-streams --log-group-name /unicorn/eks/book-app --order-by LastEventTime --descending --limit 1 --query "logStreams[0].logStreamName" --output text)" --limit 1 --start-from-head --query "events[-1].message" --output text | jq -r 'keys_unsorted | sort | join(",")'
aws logs filter-log-events --log-group-name /unicorn/eks/book-app --filter-pattern '"/health"' --query "events[].message" --output text | grep -c .

echo "=== 11-2-A ==="
kubectl get pods -n monitoring -o custom-columns='NAME:.metadata.name,STATUS:.status.phase' --no-headers | grep -iE "prometheus-|grafana"
kubectl get servicemonitor -A -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' 2>/dev/null | grep -iE "kube-controller-manager|kube-scheduler|kube-etcd" | wc -l

echo "=== 12-1-A ==="
date -u "+%Y-%m-%dT%H:%M:%SZ"
SINCE=$(date +%s)
curl -s -X POST "https://$(aws cloudfront list-distributions --query "DistributionList.Items[?Comment=='unicorn-svc-cf'].DomainName | [0]" --output text)/v1/book" -H 'Content-Type: application/json' -d '{"client_id":"C-FRESH","username":"Fresh","email":"fresh@skills.kr","concert_name":"FreshMark"}' > /dev/null
echo "waiting 30s for log pipeline" && sleep 30
aws logs filter-log-events --log-group-name /unicorn/eks/book-app --start-time ${SINCE}000 --filter-pattern '{ $.method = "POST" && $.path = "/v1/book" }' --query "events[-1].message" --output text

echo "=== 12-2-A ==="
CF=$(aws cloudfront list-distributions --query "DistributionList.Items[?Comment=='unicorn-svc-cf'].DomainName | [0]" --output text)
sleep 60
for batch in $(seq 1 5); do
  for request in $(seq 1 50); do
    curl -s -o /dev/null --max-time 3 "https://$CF/health" &
  done
  wait
done >/dev/null 2>&1
RATE_CODE=000
for attempt in $(seq 1 12); do
  RATE_CODE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "https://$CF/health")
  [ "$RATE_CODE" = "403" ] && break
  sleep 5
done
echo "$RATE_CODE"
curl -s "https://$CF/health"

echo "=== 13-1-A ==="
echo 'manual marking'
echo "=============="
echo ""

echo "===================="
echo "        14-1        "
echo "===================="

aws dynamodb list-tables --query "TableNames" --output text
# destination-db가 출력되는지 확인합니다.

echo "===================="
echo "        14-2        "
echo "===================="

aws lambda get-function --function-name ticket-processor --query "Code.RepositoryType" --output text
# ECR이 출력되는지 확인합니다.


echo "===================="
echo "        14-3        "
echo "===================="

aws dynamodb describe-time-to-live --table-name source-db --query TimeToLiveDescription.TimeToLiveStatus --output text
# ENABLED가 출력되는지 확인합니다.


echo "===================="
echo "        14-4        "
echo "===================="

export ticket_id="T-00$((RANDOM % 100 + 100))"
export price="$((RANDOM % 10 + 1))000"
export amount="$((RANDOM % 10 + 1))"

echo "ticket_id: $ticket_id"
echo "amount * price = $amount * $price = $((amount * price))"

# 필요한경우 --item 데이터에서 추가 필드를 넣어도 무방함.
aws dynamodb put-item --table-name source-db --item '{"ticket_id": {"S": "'$ticket_id'"}, "amount": {"S": "'$amount'"}, "price": {"S": "'$price'"}, "created_at": {"S": "1234567890"}}'

echo "sleep for 60 seconds..."
sleep 60

aws dynamodb get-item --table-name destination-db --key '{"ticket_id": {"S": "'$ticket_id'"}}' --query "Item.total_price"
# amount * price의 값과 total_price의 최종 출력 값이 일치하는지 확인합니다


echo "===================="
echo "        14-5        "
echo "===================="

aws dynamodb describe-table --table-name source-db --query "Table.StreamSpecification.StreamEnabled" --output text
# True가 출력되는지 확인합니다.