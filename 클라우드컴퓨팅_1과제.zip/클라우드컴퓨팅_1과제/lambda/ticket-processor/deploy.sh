#!/bin/bash
# ticket-processor 전체 구성 (테이블, Stream, TTL, ECR, 컨테이너 Lambda, 콜드스타트 방지)
# docker가 있는 곳(EC2/로컬)에서 이 폴더로 이동 후 실행
set -e
R=ap-northeast-2
ACC=$(aws sts get-caller-identity --query Account --output text)
REG=$ACC.dkr.ecr.$R.amazonaws.com
REPO=ticket-processor
FN=ticket-processor
ROLE=ticket-processor-role
TAG=v1

# 1) 테이블 (PK: ticket_id)
for t in source-db destination-db; do
  aws dynamodb describe-table --table-name $t >/dev/null 2>&1 || \
  aws dynamodb create-table --table-name $t --billing-mode PAY_PER_REQUEST \
    --attribute-definitions AttributeName=ticket_id,AttributeType=S \
    --key-schema AttributeName=ticket_id,KeyType=HASH >/dev/null
done
aws dynamodb wait table-exists --table-name source-db
aws dynamodb wait table-exists --table-name destination-db

# 2) source-db: Stream + TTL(expire_at)
aws dynamodb update-table --table-name source-db \
  --stream-specification StreamEnabled=true,StreamViewType=NEW_IMAGE >/dev/null 2>&1 || true
aws dynamodb update-time-to-live --table-name source-db \
  --time-to-live-specification "Enabled=true,AttributeName=expire_at" >/dev/null 2>&1 || true
sleep 5
STREAM_ARN=$(aws dynamodb describe-table --table-name source-db --query Table.LatestStreamArn --output text)

# 3) ECR + 이미지 (Lambda는 provenance 매니페스트를 거부하므로 --provenance=false)
aws ecr describe-repositories --repository-names $REPO >/dev/null 2>&1 || \
  aws ecr create-repository --repository-name $REPO --image-scanning-configuration scanOnPush=true >/dev/null
aws ecr get-login-password | docker login --username AWS --password-stdin $REG
docker build --platform linux/amd64 --provenance=false -t $REG/$REPO:$TAG .
docker push $REG/$REPO:$TAG

# 4) 실행 Role (최소 권한)
cat > /tmp/trust.json <<J
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},
 "Action":"sts:AssumeRole","Condition":{"StringEquals":{"aws:SourceAccount":"$ACC"}}}]}
J
cat > /tmp/perm.json <<J
{"Version":"2012-10-17","Statement":[
 {"Effect":"Allow","Action":["dynamodb:DescribeStream","dynamodb:GetRecords","dynamodb:GetShardIterator","dynamodb:ListStreams"],
  "Resource":"$STREAM_ARN"},
 {"Effect":"Allow","Action":["dynamodb:PutItem"],"Resource":"arn:aws:dynamodb:$R:$ACC:table/destination-db"},
 {"Effect":"Allow","Action":["dynamodb:UpdateItem"],"Resource":"arn:aws:dynamodb:$R:$ACC:table/source-db"},
 {"Effect":"Allow","Action":["logs:CreateLogGroup"],"Resource":"arn:aws:logs:$R:$ACC:log-group:/aws/lambda/$FN"},
 {"Effect":"Allow","Action":["logs:CreateLogStream","logs:PutLogEvents"],"Resource":"arn:aws:logs:$R:$ACC:log-group:/aws/lambda/$FN:*"}]}
J
aws iam create-role --role-name $ROLE --assume-role-policy-document file:///tmp/trust.json >/dev/null 2>&1 || true
aws iam put-role-policy --role-name $ROLE --policy-name $ROLE-policy --policy-document file:///tmp/perm.json
sleep 10

# 5) 컨테이너 Lambda
if aws lambda get-function --function-name $FN >/dev/null 2>&1; then
  aws lambda update-function-code --function-name $FN --image-uri $REG/$REPO:$TAG >/dev/null
else
  aws lambda create-function --function-name $FN --package-type Image \
    --code ImageUri=$REG/$REPO:$TAG --architectures x86_64 \
    --role arn:aws:iam::$ACC:role/$ROLE --timeout 30 --memory-size 256 \
    --environment "Variables={SOURCE_TABLE=source-db,DEST_TABLE=destination-db,TTL_SECONDS=300}" >/dev/null
fi
aws lambda wait function-updated-v2 --function-name $FN

# 6) 콜드스타트 방지: 버전 발행 → alias(live) → Provisioned Concurrency 1
VER=$(aws lambda publish-version --function-name $FN --query Version --output text)
aws lambda create-alias --function-name $FN --name live --function-version $VER >/dev/null 2>&1 || \
  aws lambda update-alias --function-name $FN --name live --function-version $VER >/dev/null
aws lambda put-provisioned-concurrency-config --function-name $FN --qualifier live \
  --provisioned-concurrent-executions 1 >/dev/null

# 7) Stream → alias 연결 (INSERT만, 즉시 전달)
if [ -z "$(aws lambda list-event-source-mappings --function-name $FN:live --event-source-arn $STREAM_ARN --query 'EventSourceMappings[0].UUID' --output text | grep -v None)" ]; then
  aws lambda create-event-source-mapping --function-name $FN:live \
    --event-source-arn $STREAM_ARN --starting-position LATEST \
    --batch-size 10 --maximum-batching-window-in-seconds 0 \
    --function-response-types ReportBatchItemFailures \
    --filter-criteria '{"Filters":[{"Pattern":"{\"eventName\":[\"INSERT\"]}"}]}' >/dev/null
fi

echo "Provisioned Concurrency 상태:"
aws lambda get-provisioned-concurrency-config --function-name $FN --qualifier live --query Status --output text
