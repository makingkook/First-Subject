"""ticket-processor (컨테이너 Lambda)
source-db 의 DynamoDB Stream(INSERT) → price * amount = total_price 를 계산해 destination-db 에 저장.
- price/amount 가 문자열(S)로 들어와도 숫자로 변환 (채점 시 S 타입으로 PUT 함)
- 처리 후 source-db 항목에 expire_at(현재+300초, 숫자)을 기록 → TTL로 300초 뒤 삭제
"""
import json
import os
import time
from decimal import Decimal, InvalidOperation

import boto3

DDB = boto3.client("dynamodb")
SOURCE_TABLE = os.environ.get("SOURCE_TABLE", "source-db")
DEST_TABLE = os.environ.get("DEST_TABLE", "destination-db")
TTL_SECONDS = int(os.environ.get("TTL_SECONDS", "300"))


def _num(attr):
    """DynamoDB 속성({'S': '5000'} 또는 {'N': '5000'})을 Decimal로."""
    if not attr:
        raise ValueError("missing number attribute")
    raw = attr.get("N", attr.get("S"))
    try:
        return Decimal(str(raw).strip())
    except (InvalidOperation, TypeError) as e:
        raise ValueError(f"not a number: {raw!r}") from e


def _n(d):
    # Decimal → DynamoDB N 문자열 (불필요한 .0 제거)
    d = d.normalize()
    return format(d.quantize(Decimal(1)) if d == d.to_integral_value() else d, "f")


def _process(new_image):
    ticket_id = new_image["ticket_id"]["S"]
    price = _num(new_image.get("price"))
    amount = _num(new_image.get("amount"))
    total = price * amount

    item = {
        "ticket_id": {"S": ticket_id},
        "price": {"N": _n(price)},
        "amount": {"N": _n(amount)},
        "total_price": {"N": _n(total)},
    }
    if "created_at" in new_image:          # 원래 타입(S/N) 그대로 보존
        item["created_at"] = new_image["created_at"]

    DDB.put_item(TableName=DEST_TABLE, Item=item)

    # source-db TTL용 숫자 필드 기록 (MODIFY 이벤트는 이벤트 필터로 무시)
    DDB.update_item(
        TableName=SOURCE_TABLE,
        Key={"ticket_id": {"S": ticket_id}},
        UpdateExpression="SET expire_at = if_not_exists(expire_at, :e)",
        ConditionExpression="attribute_exists(ticket_id)",
        ExpressionAttributeValues={":e": {"N": str(int(time.time()) + TTL_SECONDS)}},
    )
    print(json.dumps({"ticket_id": ticket_id, "price": _n(price), "amount": _n(amount),
                      "total_price": _n(total)}))


def handler(event, context):
    failures = []
    for rec in event.get("Records", []):
        if rec.get("eventName") != "INSERT":
            continue
        try:
            _process(rec["dynamodb"]["NewImage"])
        except DDB.exceptions.ConditionalCheckFailedException:
            pass  # 이미 삭제된 원본 → destination 저장은 완료됨
        except Exception as e:  # noqa: BLE001
            print(json.dumps({"level": "error", "error": str(e), "record": rec.get("eventID")}))
            failures.append({"itemIdentifier": rec["dynamodb"]["SequenceNumber"]})
    return {"batchItemFailures": failures}
