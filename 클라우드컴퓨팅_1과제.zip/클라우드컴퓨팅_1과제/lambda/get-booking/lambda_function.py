"""unicorn-get-booking-func
ALB(Lambda 타깃)에서 GET /v1/book?booking_id=...&email=...&concert_name=... 요청을 받아
unicorn-concert-db 에서 예약을 조회해 JSON으로 반환한다.
"""
import json
import os
from decimal import Decimal
from urllib.parse import unquote_plus

import boto3

TABLE = boto3.resource("dynamodb").Table(os.environ.get("TABLE_NAME", "unicorn-concert-db"))
OPTIONAL_FIELDS = ("email", "concert_name")


def _resp(status, body):
    reason = {200: "OK", 400: "Bad Request", 404: "Not Found", 405: "Method Not Allowed",
              500: "Internal Server Error"}.get(status, "")
    return {
        "statusCode": status,
        "statusDescription": f"{status} {reason}",
        "isBase64Encoded": False,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body, ensure_ascii=False, default=_json_default),
    }


def _json_default(o):
    if isinstance(o, Decimal):
        return int(o) if o == o.to_integral_value() else float(o)
    raise TypeError


def _query(event):
    # ALB는 쿼리 값을 URL 인코딩된 상태로 전달함
    q = event.get("queryStringParameters") or {}
    if not q and event.get("multiValueQueryStringParameters"):
        q = {k: v[-1] for k, v in event["multiValueQueryStringParameters"].items() if v}
    return {k: unquote_plus(v) for k, v in q.items() if v is not None}


def lambda_handler(event, context):
    if event.get("httpMethod", "GET") != "GET":
        return _resp(405, {"message": "method not allowed"})

    q = _query(event)
    booking_id = q.get("booking_id", "").strip()
    if not booking_id:
        return _resp(400, {"message": "booking_id is required"})

    try:
        item = TABLE.get_item(Key={"booking_id": booking_id}).get("Item")
    except Exception as e:  # noqa: BLE001
        print(json.dumps({"level": "error", "msg": "get_item failed", "error": str(e)}))
        return _resp(500, {"message": "internal error"})

    if not item:
        return _resp(404, {"message": "booking not found"})

    # optional 조건이 들어오면 함께 만족해야 함
    for f in OPTIONAL_FIELDS:
        if f in q and q[f] != "" and str(item.get(f, "")) != q[f]:
            return _resp(404, {"message": "booking not found"})

    return _resp(200, item)
