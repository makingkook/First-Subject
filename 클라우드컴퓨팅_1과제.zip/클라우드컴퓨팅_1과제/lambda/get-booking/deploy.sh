#!/bin/bash
# unicorn-get-booking-func 배포 (CloudShell에서 이 폴더로 이동 후 실행)
set -e
R=ap-northeast-2
ACC=$(aws sts get-caller-identity --query Account --output text)
FN=unicorn-get-booking-func
ROLE=unicorn-get-booking-role
LG=/unicorn/lambda/get-booking
TABLE_ARN=arn:aws:dynamodb:$R:$ACC:table/unicorn-concert-db
PLATFORM_KEY=$(aws kms describe-key --key-id alias/unicorn-kms-platform --query KeyMetadata.Arn --output text)
APP_KEY=$(aws kms describe-key --key-id alias/unicorn-kms-app --query KeyMetadata.Arn --output text)

# 1) 로그 그룹 (Platform 키 암호화)
aws logs create-log-group --log-group-name $LG --kms-key-id $PLATFORM_KEY 2>/dev/null || true
aws logs put-retention-policy --log-group-name $LG --retention-in-days 30

# 2) 실행 Role (최소 권한)
cat > /tmp/trust.json <<J
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},
 "Action":"sts:AssumeRole","Condition":{"StringEquals":{"aws:SourceAccount":"$ACC"}}}]}
J
cat > /tmp/perm.json <<J
{"Version":"2012-10-17","Statement":[
 {"Effect":"Allow","Action":["dynamodb:GetItem"],"Resource":"$TABLE_ARN"},
 {"Effect":"Allow","Action":["kms:Decrypt"],"Resource":"$APP_KEY",
  "Condition":{"StringEquals":{"kms:ViaService":"dynamodb.$R.amazonaws.com"}}},
 {"Effect":"Allow","Action":["logs:CreateLogStream","logs:PutLogEvents"],
  "Resource":"arn:aws:logs:$R:$ACC:log-group:$LG:*"}]}
J
aws iam create-role --role-name $ROLE --assume-role-policy-document file:///tmp/trust.json >/dev/null 2>&1 || true
aws iam put-role-policy --role-name $ROLE --policy-name $ROLE-policy --policy-document file:///tmp/perm.json
sleep 10

# 3) 함수 생성 (환경변수는 Platform 키로 암호화, 로그는 지정 로그 그룹으로)
rm -f function.zip && zip -q function.zip lambda_function.py
if aws lambda get-function --function-name $FN >/dev/null 2>&1; then
  aws lambda update-function-code --function-name $FN --zip-file fileb://function.zip >/dev/null
else
  aws lambda create-function --function-name $FN \
    --runtime python3.12 --architectures x86_64 \
    --handler lambda_function.lambda_handler \
    --role arn:aws:iam::$ACC:role/$ROLE \
    --zip-file fileb://function.zip \
    --timeout 10 --memory-size 256 \
    --environment "Variables={TABLE_NAME=unicorn-concert-db}" \
    --kms-key-arn $PLATFORM_KEY \
    --logging-config "LogFormat=Text,LogGroup=$LG" >/dev/null
fi
aws lambda wait function-active-v2 --function-name $FN

# 4) Lambda 타깃 그룹이 이미 있으면 ALB 호출 권한 부여 (LAMBDA_TG_ARN 환경변수로 전달)
if [ -n "$LAMBDA_TG_ARN" ]; then
  aws lambda add-permission --function-name $FN --statement-id alb-invoke \
    --principal elasticloadbalancing.amazonaws.com --action lambda:InvokeFunction \
    --source-arn "$LAMBDA_TG_ARN" 2>/dev/null || true
  aws elbv2 register-targets --target-group-arn "$LAMBDA_TG_ARN" \
    --targets Id=$(aws lambda get-function --function-name $FN --query Configuration.FunctionArn --output text)
fi

aws lambda get-function-configuration --function-name $FN \
  --query "[FunctionName, KMSKeyArn, LoggingConfig.LogGroup]" --output json | jq -r ".[]"
